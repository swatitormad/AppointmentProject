
		import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.java.entity.SigninModel;
public class SigninHibernate {

	public static void main(String[] args) {
		
		
		SigninModel s = new SigninModel();
		
		s.setUname("swati");
		s.setPwd("swati123");
		s.setRpwd("swati123");
			

			//1.Configuration load
			Configuration cfg=new Configuration();
			cfg.configure("hibernate.cfg.xml");

			//2.get session factory(connection with data base)
			SessionFactory sf=cfg.buildSessionFactory();

			//3.get session(get session to execute queries)
			Session session=sf.openSession();

			//4.transaction(session complete commit)or fail(rollback)
			Transaction tr=session.beginTransaction();
			
			session.save(s);
			tr.commit();
			session.close();
			sf.close();
	}

}
