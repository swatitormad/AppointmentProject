
public class SigninHibernate {

	public static void main(String[] args) {
		import org.hibernate.Session;
		import org.hibernate.SessionFactory;
		import org.hibernate.Transaction;
		import org.hibernate.cfg.Configuration;

			Employee emp=new Employee();
			emp.setId(1);
			emp.setName("sneha");
			emp.setGender("female");
			
			Address a=new Address();
			a.setId(1);
			a.setPin("416");
			a.setCity("kolhapure");
			a.setState("MH");
			a.setEmpid(emp);
			

			//1.Configuration load
			Configuration cfg=new Configuration();
			cfg.configure();

			//2.get session factory(connection with data base)
			SessionFactory sf=cfg.buildSessionFactory();

			//3.get session(get session to execute queries)
			Session session=sf.openSession();

			//4.transaction(session complete commit)or fail(rollback)
			Transaction tr=session.beginTransaction();
			session.save(emp);
			session.save(a);
			tr.commit();
			session.close();
			sf.close();

	}

}
