

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.java.entity.SigninModel;

public class SignInValidation extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		
		String name=request.getParameter("uname");
		String password =request.getParameter("pwd");
		String retype=request.getParameter("rpwd");


		SigninModel c=new SigninModel();

		c.setUname(name);
		c.setPwd(password);
		c.setRpwd(retype);
	

		SigninHibernate sh = new SigninHibernate();
		if(password.length()>4 && password.length()<15)
		{
			System.out.println("msg=success");
		}
		else
		{
			System.out.println("msg error");
		}

		
	}

}
