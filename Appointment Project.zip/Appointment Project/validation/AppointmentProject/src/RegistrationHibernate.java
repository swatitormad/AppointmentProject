import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.java.entity.RegistrationModel;

public class RegistrationHibernate {
	public static void main(String[] args) 
	{
		RegistrationModel rm = new RegistrationModel();
		
		rm.setUid(876543);
		rm.setUname("swati");
		rm.setEmail("swati@gmail.com");
		rm.setPwd("swati@123");
		rm.setRpwd("swati@123");
		rm.setUphone("2345678");
		rm.setUadd("pune");
		rm.setG("female");
		
		//1.Configuration load
		Configuration cfg=new Configuration();
		cfg.configure("hibernate.cfg.xml");

		//2.get session factory(connection with data base)
		SessionFactory sf=cfg.buildSessionFactory();

		//3.get session(get session to execute queries)
		Session session=sf.openSession();

		//4.transaction(session complete commit)or fail(rollback)
		Transaction tr=session.beginTransaction();
		
		session.save(rm);
		tr.commit();
		session.close();
		sf.close();

	}


		
	
	
	
	
	
	
	
	
	
	
	

	

}
