package com.java.entity;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "LoginTable")
public class SigninModel {
@Id
private String uname;
private String pwd;
private String rpwd;
public String getUname() {
	return uname;
}
public void setUname(String uname) {
	this.uname = uname;
}
public String getPwd() {
	return pwd;
}
public void setPwd(String pwd) {
	this.pwd = pwd;
}
public String getRpwd() {
	return rpwd;
}
public void setRpwd(String rpwd) {
	this.rpwd = rpwd;
}


}
