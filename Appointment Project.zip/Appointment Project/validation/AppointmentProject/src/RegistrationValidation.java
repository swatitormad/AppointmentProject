

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class RegistrationValidation extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		String id=request.getParameter("uid");
		String name=request.getParameter("uname");
		String email=request.getParameter("email");
		String pass=request.getParameter("pwd");
		String rpass =request.getParameter("rpwd");
		String phone=request.getParameter("uphone");
		String address = request.getParameter("uadd");
		String gender = request.getParameter("g");
		

	}

}
